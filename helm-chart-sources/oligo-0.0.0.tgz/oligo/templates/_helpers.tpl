{{/*
Expand the name of the chart.
*/}}
{{- define "oligo.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "fluentBitEnv" -}}
- name: NAMESPACE
  valueFrom:
    fieldRef:
      fieldPath: metadata.namespace
- name: POD_ID
  valueFrom:
    fieldRef:
      fieldPath: metadata.uid
- name: CONTAINER_NAME
  value: {{ .containerName }}
{{- end }}

{{- define "fluentBitConfigVolumeMounts" -}}
{{- if .Values.fluentBit.enabled }}
- mountPath: /fluent-bit-template.conf
  name: fluent-bit-config-template
  subPath: fluent-bit.conf
- mountPath: /conf
  name: fluent-bit-config
{{- end }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "oligo.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "oligo.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "oligo.version" -}}
{{- printf "%s" .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Secrets
*/}}
{{- define "oligo.imagePullSecretName" -}}
{{- default (printf "%s-imagepullkey" (include "oligo.fullname" .)) .Values.imagePullSecret.name -}}
{{- end -}}

{{- define "oligo.imagePullSecretValue" -}}
{{- $format := "{\"auths\": {\"%s\": {\"auth\": \"%s\"}}}" -}}
{{- $creds := printf "%s:%s" (required "A valid username for image pull secret required" .Values.imagePullSecret.username) .Values.imagePullSecret.password -}}
{{- printf $format (default "docker.io" .Values.image.registry) (b64enc $creds) | b64enc -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "oligo.labels" -}}
helm.sh/chart: {{ include "oligo.chart" . }}
oligo/donotscan: "enabled"
oligo/shiplogs: "enabled"
{{ include "oligo.selectorLabels" . }}
{{- range $key, $value := .Values.commonLabels }}
{{ $key }}: {{ $value | quote }}
{{- end }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "oligo.selectorLabels" -}}
app.kubernetes.io/name: {{ include "oligo.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}


{{- define "appVersion" -}}
{{- .Chart.AppVersion -}}
{{- end -}}

{{- define "oligo.imageTag" -}}
{{- default (include "appVersion" .) .Values.image.tag -}}
{{- end -}}

{{/* Collector */}}

{{- define "collector.fullname" -}}
{{- printf "%s-%s" .Release.Name "collector" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "collector.imageTag" -}}
{{- include "oligo.imageTag" . -}}
{{- end -}}

{{- define "collector.image" -}}
{{- if .Values.image.registry -}}
{{- printf "%s/%s:%s" .Values.image.registry .Values.collector.image.repository (include "collector.imageTag" .) -}}
{{- else -}}
{{- printf "%s:%s" .Values.collector.image.repository (include "collector.imageTag" .) -}}
{{- end -}}
{{- end -}}

{{- define "collector.grpcServerPort" -}}
50051
{{- end -}}

{{- define "collector.httpsServerPort" -}}
443
{{- end -}}

{{/*
Collector Selector labels
*/}}
{{- define "collector.selectorLabels" -}}
oligo/app: collector
{{- end }}

{{/* Labels must contain the selector labels */}}
{{- define "collector.labels" -}}
{{ include "collector.selectorLabels" . }}
app.kubernetes.io/component: collector
{{- end -}}

{{/*
Create the name of collector service
*/}}
{{- define "collector.serviceName" -}}
{{- printf "%s-%s" (include "collector.fullname" .) "svc" }}
{{- end }}

{{/* Scanner */}}

{{- define "scanner.fullname" -}}
{{- printf "%s-%s" .Release.Name "scanner" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "scanner.imageTag" -}}
{{- include "oligo.imageTag" . -}}
{{- end -}}

{{- define "scanner.image" -}}
{{- if .Values.image.registry -}}
{{- printf "%s/%s:%s" .Values.image.registry .Values.scanner.image.repository (include "scanner.imageTag" .) -}}
{{- else -}}
{{- printf "%s:%s" .Values.scanner.image.repository (include "scanner.imageTag" .) -}}
{{- end -}}
{{- end -}}

{{- define "scanner.grpcServerPort" -}}
50051
{{- end -}}

{{/*
Scanner Selector labels
*/}}
{{- define "scanner.selectorLabels" -}}
oligo/app: scanner
{{- end }}

{{/* Labels must contain the selector labels */}}
{{- define "scanner.labels" -}}
{{ include "scanner.selectorLabels" . }}
app.kubernetes.io/component: scanner
{{- end -}}

{{/*
Create the name of scanner service
*/}}
{{- define "scanner.serviceName" -}}
{{- printf "%s-%s" (include "scanner.fullname" .) "svc" }}
{{- end }}

{{/*
Create the name of the Scanner service account to use
*/}}
{{- define "scanner.serviceAccountName" -}}
{{- if not .Values.operator.enabled -}}
{{- printf "%s-%s" .Release.Name "scanner-sa" -}}
{{- else -}}
oligo-scanner
{{- end -}}
{{- end -}}


{{/*
Create the name of the cluster role to use
*/}}
{{- define "scanner.clusterRoleName" -}}
{{- printf "%s-%s" (include "scanner.fullname" .) "cluster-role" }}
{{- end }}

{{/*
Create the name of the cluster role binding to use
*/}}
{{- define "scanner.clusterRoleBindingName" -}}
{{- printf "%s-%s" (include "scanner.fullname" .) "cluster-role-binding" }}
{{- end }}

{{/*
Create the name of scanner deployment
*/}}
{{- define "scanner.deploymentName" -}}
{{- printf "%s-%s" (include "scanner.fullname" .) "watchdog" }}
{{- end }}

{{/*
Create the name of the cluster role to use
*/}}
{{- define "sensor.clusterRoleName" -}}
{{- printf "%s-%s" .Release.Name "sensor-cluster-role" }}
{{- end }}

{{/*
Create the name of the cluster role binding to use
*/}}
{{- define "sensor.clusterRoleBindingName" -}}
{{- printf "%s-%s" .Release.Name "sensor-cluster-role-binding" }}
{{- end }}

{{/* General Sensor */}}

{{/*
Create the name of the sensor service account to use
*/}}
{{- define "sensor.serviceAccountName" -}}
{{- if not .Values.operator.enabled -}}
{{- printf "%s-%s" .Release.Name "sensor-sa" -}}
{{- else -}}
oligo-sensor
{{- end -}}
{{- end -}}

{{/* Merged Sensor */}}

{{- define "sensor.fullname" -}}
{{- printf "%s-%s" .Release.Name "sensor" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "sensor.imageTag" -}}
{{- include "oligo.imageTag" . -}}
{{- end -}}

{{- define "sensor.image" -}}
{{- if .Values.image.registry -}}
{{- printf "%s/%s:%s" .Values.image.registry .Values.sensor.image.repository (include "sensor.imageTag" .) -}}
{{- else -}}
{{- printf "%s:%s" .Values.sensor.image.repository (include "sensor.imageTag" .) -}}
{{- end -}}
{{- end -}}

{{/*
Merged sensor Selector labels
*/}}
{{- define "sensor.selectorLabels" -}}
oligo/app: sensor
{{- end }}

{{/* Labels must contain the selector labels */}}
{{- define "sensor.labels" -}}
{{ include "sensor.selectorLabels" . }}
app.kubernetes.io/component: sensor
{{- end -}}

{{/*
Volatile storage dir
*/}}
{{- define "sensor.volatileStorageDir" -}}
/volatilestorage
{{- end -}}

{{/*
Persistent storage dir.
This dir is used to store persistent data to be kept across pod restarts.
*/}}
{{- define "sensor.persistentStorageDir" -}}
/persistentstorage
{{- end -}}

{{/* Prometheus */}}

{{- define "prometheus.clientMetricsAnnotations" -}}
{{- if .Values.common.exposeClientMetrics -}}
prometheus.io/scrape: "true"
prometheus.io/path: "/metrics"
prometheus.io/port: "{{ .Values.common.prometheus.clientServicePort }}"
{{- end -}}
{{- end -}}

{{/*
Prometheus client port
*/}}

{{- define "prometheus.clientPortName" -}}
client-prom
{{- end -}}

{{- define "prometheus.oligoPortName" -}}
oligo-prom
{{- end }}

{{/*
Kubernetes liveness probe spec for container health checks
*/}}
{{- define "oligo.livenessProbe" -}}
{{- if .Values.common.livenessProbe.enabled }}
livenessProbe:
  httpGet:
    path: /healthz
    port: {{ .Values.common.prometheus.oligoServicePort }}
  initialDelaySeconds: {{ .Values.common.livenessProbe.initialDelaySeconds }}
  periodSeconds: {{ .Values.common.livenessProbe.periodSeconds }}
  failureThreshold: {{ .Values.common.livenessProbe.failureThreshold }}
  timeoutSeconds: {{ .Values.common.livenessProbe.timeoutSeconds }}
{{- end }}
{{- end }}

{{- define "fluent-bit.configmap.fullname" -}}
{{- printf "%s-%s" .Release.Name "fluent-bit-config-map" | trunc 63 | trimSuffix "-" }}
{{- end -}}

{{/*
Fluentbit volumes. Do not modify without deep understanding of fluentbit
*/}}
{{- define "fluent-bit.volumes" -}}
{{- if .Values.fluentBit.enabled }}
- name: varlog
  hostPath:
    path: /var/log
- name: varlibdockercontainers
  hostPath:
    path: /var/lib/docker/containers
- name: etcmachineid
  hostPath:
    path: /etc/machine-id
    type: File
- name: fluent-bit-config-template
  configMap:
    name: {{ include "fluent-bit.configmap.fullname" . }}
    defaultMode: 0777
- name: fluent-bit-config
  emptyDir: {}
{{- end }}
{{- end }}

{{- define "fluent-bit.annotations" -}}
{{- if .Values.fluentBit.enabled }}
checksum/fluent-bit.conf: {{ include (print $.Template.BasePath "/fluentbit/fluentbit-config-map.yaml") . | sha256sum }}
{{- end }}
{{- end }}

{{- define "falco.annotations" -}}
{{- if .Values.sensor.falco.enabled }}
checksum/falco.conf: {{ include (print $.Template.BasePath "/falco/falco-config-map.yaml") . | sha256sum }}
{{- end }}
{{- end }}

{{- define "commonConfig" -}}
clientId: {{ .Values.clientId }}
{{- if .Values.clusterName }}
clusterName: {{ .Values.clusterName }}
{{- end }}
gatewaySecretFilePath: {{ .Values.gatewaySecretFilePath }}
apiKeySecretFilePath: {{ .Values.apiKeySecretFilePath }}
nativeHostIdentifier: {{ .Values.nativeHostIdentifier }}
monitorMode: {{ .Values.monitorMode | toYaml | nindent 2 }}
gatewayHost: {{ .Values.oligoCloudEndpoint }}
gatewayApiVersion: {{ .Values.oligoCloudApiVersion }}
namespacesToMonitor: {{ .Values.common.namespacesToMonitor | toYaml | nindent 2 }}
labelsToMonitor: {{ .Values.common.labelsToMonitor | toYaml | nindent 2 }}
blocklistedContainerNames: {{ .Values.common.blocklistedContainerNames | toYaml | nindent 2 }}
internalLogShipper: {{ .Values.common.internalLogShipper | toYaml | nindent 2 }}
batchSizeInKb: {{ .Values.common.batching.batchSizeInKB }}
batchInterval: {{ .Values.common.batching.batchInterval }}
batchedChannelSize: {{ .Values.common.batching.batchedChannelSize }}
promClientServicePort: {{ .Values.common.prometheus.clientServicePort }}
promOligoServicePort: {{ .Values.common.prometheus.oligoServicePort }}
exposePprof: {{ .Values.common.exposePprof }}
sendProfilesToPyroscope: {{ .Values.common.sendProfilesToPyroscope | toYaml | nindent 2 }}
highLoadMonitoring: {{ .Values.common.highLoadMonitoring | toYaml | nindent 2 }}
useWhitelistPodSpec: {{ .Values.common.useWhitelistPodSpec }}
filesWithDebugLogs: {{ .Values.common.filesWithDebugLogs | toYaml | nindent 2 }}
logToExternalFile: {{ .Values.common.logToExternalFile }}
logJSONToStdout: {{ .Values.common.logJSONToStdout }}
externalLogFilePath: {{ .Values.common.externalLogFilePath }}
externalDebugLogFilePath: {{ .Values.common.externalDebugLogFilePath }}
externalLogFileMaxSize: {{ .Values.common.externalLogFileMaxSize }}
exposeClientMetrics: {{ .Values.common.exposeClientMetrics }}
exposeMetricsServer: {{ .Values.common.exposeMetricsServer }}
livenessProbeEnabled: {{ .Values.common.livenessProbe.enabled }}
remoteWriteMetricsDirectly: {{ .Values.common.remoteWriteMetricsDirectly }}
remoteWriteMetricsInterval: {{ .Values.common.remoteWriteMetricsInterval | toYaml | nindent 2 }}
nativeRun: {{ .Values.common.nativeSensorRun }}
logToStdout: {{ .Values.common.logToStdout }}
logOnlyInfoToStdout: {{ .Values.common.logOnlyInfoToStdout }}
reportOligoPods: {{ .Values.common.oligoPodsReporting }}
fluentBitEnabled: {{ .Values.fluentBit.enabled }}
grpcWaitForReady: {{ .Values.common.grpcWaitForReady }}
grpcConnectionTimeout: {{ .Values.common.grpcConnectionTimeout }}
featureInternetFacing: {{ .Values.common.featureInternetFacing }}
featureValidateHTTPSEndpoints: {{ .Values.common.featureValidateHTTPSEndpoints }}
networkScanInterval: {{ .Values.common.networkScanInterval }}
podsChunkSize: {{ .Values.common.podsChunkSize }}
ring: {{ .Values.ring }}
{{- if .Values.httpsProxyConfiguration.caCertificate }}
caCertificate: {{ .Values.httpsProxyConfiguration.caCertificate }}
{{- end }}
dedupLibraries: {{ .Values.common.dedupLibraries }}
enableCoverageMonitoring: {{ .Values.common.enableCoverageMonitoring }}
collectorHost: {{ include "collector.serviceName" . }}:{{ include "collector.grpcServerPort" . }}
collectorProxyHost: {{ include "collector.serviceName" . }}:{{ include "collector.httpsServerPort" . }}
useExternalCollector: {{ .Values.sensor.useExternalCollector }}
useExternalScanner: {{ .Values.sensor.useExternalScanner }}
httpsDisableKeepAlives: {{ .Values.common.httpsDisableKeepAlives }}
featureHTTPSThroughCollector: {{ .Values.common.featureHTTPSThroughCollector }}
mTLS: {{ .Values.common.mTLS | toYaml | nindent 2}}
liveConfiguration: {{ .Values.common.liveConfiguration | toYaml | nindent 2}}
customerSettingsPolling: {{ .Values.common.customerSettingsPolling | toYaml | nindent 2}}
{{- end }}

{{/*
Compute the NO_PROXY value by automatically including:
- Internal Oligo services (collector, scanner)
- Kubernetes API server IP (referenced via $(KUBERNETES_SERVICE_HOST) which Kubernetes injects)
- User-specified noProxy values
*/}}
{{- define "oligo.noProxy" -}}
{{- $noProxy := printf "%s,%s,$(KUBERNETES_SERVICE_HOST)" (include "collector.serviceName" .) (include "scanner.serviceName" .) -}}
{{- if .Values.httpsProxyConfiguration.noProxy -}}
{{- $noProxy = printf "%s,%s" $noProxy .Values.httpsProxyConfiguration.noProxy -}}
{{- end -}}
{{- $noProxy -}}
{{- end -}}

{{- define "commonEnvVars" -}}
{{- $secretName := .Values.gatewaySecretName | default .Values.apiKeySecretName | default "oligo-apikey" }}
{{- if not (or .Values.gatewaySecretFilePath .Values.apiKeySecretFilePath) }}
- name: OLIGO_GATEWAY_SECRET
  valueFrom:
    secretKeyRef:
      name: "{{ $secretName }}"
      key: "apikey"
{{- end }}
- name: NODE_NAME
  valueFrom:
    fieldRef:
      fieldPath: spec.nodeName
- name: POD_NAME
  valueFrom:
    fieldRef:
      fieldPath: metadata.name
{{- if .Values.httpsProxyConfiguration.enabled }}
- name: HTTPS_PROXY
  value: {{ .Values.httpsProxyConfiguration.url }}
- name: HTTP_PROXY # Fluent Bit supports configuring an HTTP proxy for all egress HTTP/HTTPS traffic via the HTTP_PROXY environment variable.
  value: {{ .Values.httpsProxyConfiguration.url }}
- name: NO_PROXY
  value: {{ include "oligo.noProxy" . }}
{{- end }}
{{- end }}

{{- define "chartVerEnvVar" -}}
- name: CHART_VERSION
  value: {{ include "oligo.version" . }}
{{- end }}

{{- define "extraEnvVars" -}}
{{- if .Values.common.extraEnvVars -}}
{{- toYaml .Values.common.extraEnvVars -}}
{{- end -}}
{{- end -}}


{{/* ConfigMap */}}

{{- define "scanner.configMapName" -}}
{{- printf "%s-%s" .Release.Name "scanner-config" }}
{{- end -}}

{{- define "collector.configMapName" -}}
{{- printf "%s-%s" .Release.Name "collector-config" }}
{{- end -}}

{{- define "sensor.configMapName" -}}
{{- printf "%s-%s" .Release.Name "sensor-config" }}
{{- end -}}

{{- define "scanner.configMapVolume" -}}
- name: config-volume
  configMap:
    name: {{ include "scanner.configMapName" . }}
{{- end -}}

{{- define "collector.configMapVolume" -}}
- name: config-volume
  configMap:
    name: {{ include "collector.configMapName" . }}
{{- end -}}

{{- define "sensor.configMapVolume" -}}
- name: config-volume
  configMap:
    name: {{ include "sensor.configMapName" . }}
{{- end -}}

{{- define "oligo.configFileName" -}}
config.yaml
{{- end -}}

{{- define "oligo.configMapVolumeMounts" -}}
- name: config-volume
  mountPath: /dist/{{ include "oligo.configFileName" . }}
  subPath: {{ include "oligo.configFileName" . }}
{{- end -}}

{{- define "sensor.configMapAnnotations" -}}
checksum/{{- include "oligo.configFileName" . -}}: {{ include (print $.Template.BasePath "/config/sensorconfig.yaml") . | sha256sum }}
{{- end -}}

{{- define "scanner.configMapAnnotations" -}}
checksum/{{- include "oligo.configFileName" . -}}: {{ include (print $.Template.BasePath "/config/scannerconfig.yaml") . | sha256sum }}
{{- end -}}

{{- define "collector.configMapAnnotations" -}}
checksum/{{- include "oligo.configFileName" . -}}: {{ include (print $.Template.BasePath "/config/collectorconfig.yaml") . | sha256sum }}
{{- end -}}
